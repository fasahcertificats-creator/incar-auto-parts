@echo off
title INCAR AUTO PARTS Preview
cd /d "%~dp0auto-parts-sourcing"

echo.
echo ============================================
echo  INCAR AUTO PARTS Preview
echo ============================================
echo.
echo Local preview:
echo   http://127.0.0.1:8088
echo.
echo Mobile preview:
echo   Use the IPv4 address below with port 8088
echo   Example: http://YOUR-IP:8088
echo.
ipconfig | findstr /i "IPv4"
echo.
echo Starting static preview server...
echo Keep this window open while previewing.
echo.

start "" "http://127.0.0.1:8088"
node preview-server.js

pause
